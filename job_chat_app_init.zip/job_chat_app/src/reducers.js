/**
 * Created by lenovo on 2018/3/7.
 */

import { combineReducers } from 'redux'

// 合并所有reducer

export default combineReducers({})